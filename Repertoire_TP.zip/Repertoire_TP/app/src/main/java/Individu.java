import java.util.Scanner;

public class Individu {

    Scanner entree;
    String nom, numero;

    public Individu(String nom, String numero) {

        nom = this.nom;
        numero = this.numero;

    }
}
